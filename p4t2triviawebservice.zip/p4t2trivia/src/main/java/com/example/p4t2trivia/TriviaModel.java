/**
 * Name:Paridhi Kapur Andrew id:pkapur
 *
 * Author: Paridhi Kapur
 * Date: April 7, 2023
 * The TriviaModel class fetches a trivia question from the Open Trivia Database API and parses it to extract the
 question, answer choices, and the index of the correct answer.The trivia question is fetched based on the
 category, difficulty, and type specified by the user.
 The class contains three instance variables: the API base URL, the character encoding used for API responses,
 and a Gson object for parsing JSON responses.
 The getTriviaQuestion method takes in the category, difficulty, and type of the trivia question and returns a
 Map object containing the question, answer choices, and the index of the correct answer. It uses the API_BASE_URL,
 category, difficulty, and type to construct the API endpoint and fetches the question by sending a GET request
 to the endpoint. The response is then parsed to extract the relevant information and store it in a Map object,
 which is returned.
 The parseTriviaQuestion method takes in a JSON response from the Open Trivia Database API and extracts the
 question, answer choices, and the index of the correct answer. It returns a Map object containing this information.
 The method first creates a JsonObject from the JSON response and then extracts a JsonArray containing the trivia
 question(s) from the "results" field of the JsonObject. It then extracts the question, correct answer, and incorrect
 answers from the first JsonObject in the JsonArray. It randomly selects an index for the correct answer and then
 combines the correct answer with three incorrect answers to form an array of all answer choices. It then puts the
 question, answer choices, and index of the correct answer in a Map object, which is returned.
 The fetch method takes in a URL string and sends a GET request to the specified URL. It returns the response as
 a String. The method opens a connection to the URL, sets the request method to "GET", and gets the input stream
 from the connection's response. It then reads the response stream and appends the characters to a StringBuilder
 object. The method returns the StringBuilder object as a String.

 */
package com.example.p4t2trivia;

//import statements
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class TriviaModel {

    //defining the base url to the OpenTrivia API
    private final String API_BASE_URL = "https://opentdb.com/api.php";
    private final String ENCODING = "UTF-8";
    private final Gson gson = new Gson();

    public TriviaModel() {
    }
    /**
     * Constructs the API endpoint using the specified category, difficulty, and type and sends a GET request to the
     * endpoint to fetch a trivia question. Parses the response to extract the question, answer choices, and the index
     * of the correct answer. Returns a Map object containing the extracted information.
     *
     * @param category the category of the trivia question
     * @param difficulty the difficulty of the trivia question
     * @param type the type of the trivia question
     * @return a Map object containing the trivia question, answer choices, and index of the correct answer
     * @throws IOException if an error occurs while fetching the trivia question from the API
     */
    public String getApiUrl(String category, String difficulty, String type) {
        return API_BASE_URL + "?amount=1&category=" + category + "&difficulty=" + difficulty + "&type=" + type;
    }

    /**
     * Constructs the API endpoint using the specified category, difficulty, and type and sends a GET request to the
     * endpoint to fetch a trivia question. Parses the response to extract the question, answer choices, and the index
     * of the correct answer. Returns a Map object containing the extracted information.
     *
     * @param category the category of the trivia question
     * @param difficulty the difficulty of the trivia question
     * @param type the type of the trivia question
     * @return a Map object containing the trivia question, answer choices, and index of the correct answer
     * @throws IOException if an error occurs while fetching the trivia question from the API
     */
    public Map<String, Object> getTriviaQuestion(String category, String difficulty, String type) throws IOException {
        //create the url using parameters defined, fetch the url, and return response
        String url = API_BASE_URL + "?amount=1&category=" + category + "&difficulty=" + difficulty + "&type=" + type;
        String response = fetch(url);
        return parseTriviaQuestion(response);
    }

    /**
     * Parses the given JSON response from the Open Trivia Database API into a map object containing the question, four
     * possible answers, and the index of the correct answer. The answers are randomly shuffled.
     *
     * @param response The JSON response from the Open Trivia Database API.
     * @return A map object containing the question, four possible answers, and the index of the correct answer.
     */
    private Map<String, Object> parseTriviaQuestion(String response) {
        Map<String, Object> questionMap = new HashMap<>();
        JsonObject jsonObject = gson.fromJson(response, JsonObject.class);
        JsonArray jsonArray = jsonObject.getAsJsonArray("results");
        JsonObject resultObject = jsonArray.get(0).getAsJsonObject();

        String question = resultObject.get("question").getAsString();
        String correctAnswer = resultObject.get("correct_answer").getAsString();
        JsonArray incorrectAnswersArray = resultObject.getAsJsonArray("incorrect_answers");
        String[] incorrectAnswers = new String[3];
        //storing incorrect answers in array
        for (int i = 0; i < incorrectAnswersArray.size(); i++) {
            incorrectAnswers[i] = incorrectAnswersArray.get(i).getAsString();
        }

        String[] allAnswers = new String[4];
        allAnswers[0] = correctAnswer;
        //giving correct answer an index value
        int correctIndex = new Random().nextInt(4);
        int j = 0;
        for (int i = 0; i < 4; i++) {
            if (i == correctIndex) {
                continue;
            }
            allAnswers[i] = incorrectAnswers[j];
            j++;
        }

        //placing all values in questionMap
        allAnswers[correctIndex] = correctAnswer;
        questionMap.put("question", question);
        questionMap.put("answers", allAnswers);
        questionMap.put("correctIndex", correctIndex);

        return questionMap;
    }

    /**

     Fetches data from the specified URL using a HTTP GET request.

     @param urlStr the URL to fetch data from

     @return a string representation of the fetched data

     @throws IOException if an error occurs while fetching the data
     */
    private String fetch(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        InputStreamReader in = new InputStreamReader(connection.getInputStream(), ENCODING);

        //string representation of url sb
        StringBuilder sb = new StringBuilder();
        char[] buffer = new char[1024];
        int len;
        while ((len = in.read(buffer)) != -1) {
            sb.append(buffer, 0, len);
        }
        in.close();

        return sb.toString();
    }
}