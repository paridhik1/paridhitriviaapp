/**
 * Name:Paridhi Kapur Andrew id:pkapur
 *
 * Author: Paridhi Kapur
 * Last Modified: April 7, 2023
 *
 * This program is a servlet that receives HTTP GET requests and returns a JSON response with a trivia question and its options.
 * The program retrieves the trivia question from a MongoDB Atlas cluster and sends back the question in a JSON object.
 * The request parameters are category, difficulty and type. If these parameters are not specified, default values are used.
 * The program also logs each request in a collection in the MongoDB Atlas cluster.
 */
package com.example.p4t2trivia;

//import statements
import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

@WebServlet(name = "TriviaServlet", urlPatterns = {"/getQuestion"})
public class MongoDBServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(MongoDBServlet.class.getName());

    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> logCollection;

    /**
     * Initializes the servlet by setting up a connection to the MongoDB database.
     * Also creates a new collection in the database to store the logs.
     *
     * @throws ServletException if there is an issue with initializing the servlet
     */
    @Override
    public void init() throws ServletException {
        super.init();

        // Set up a connection to the MongoDB database.

        MongoDatabase database = MongoClients.create("mongodb+srv://pkapur:distributed@cluster0.muxgpkw.mongodb.net/?retryWrites=true&w=majority")
                .getDatabase("logs");
        // Create a new collection in the database to store the logs.
        logCollection = database.getCollection("trivia");
    }

    /**
     * Processes GET requests sent to the servlet and returns a JSON response containing a trivia question.
     * Retrieves the trivia question based on specified category, difficulty and type using the TriviaModel class.
     * Also logs each request with details such as request time, phone model and response time.
     *
     * @param request  the HTTP request object
     * @param response the HTTP response object
     * @throws ServletException if there is an issue with processing the request
     * @throws IOException      if there is an issue with input/output operations
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, IOException {
        // Retrieve query parameters from the request.
        String category = request.getParameter("category");
        String difficulty = request.getParameter("difficulty");
        String type = request.getParameter("type");

        // Record the time of the request and the user-agent of the client device.
        long requestTime = System.currentTimeMillis();
        String phoneModel = request.getHeader("User-Agent");

        // Set default values for query parameters.

        if (category == null || category.isEmpty()) {
            category = "9";
        }
        if (difficulty == null || difficulty.isEmpty()) {
            difficulty = "easy";
        }
        if (type == null || type.isEmpty()) {
            type = "multiple";
        }

        // Create an instance of TriviaModel and use it to retrieve a question and its answers.
        TriviaModel triviaModel = new TriviaModel();
        Map<String, Object> questionMap = triviaModel.getTriviaQuestion(category, difficulty, type);
        long thirdPartyApiRequestTime = System.currentTimeMillis();

        // Create a JSON object to hold the question, answers, and correct answer index.

        JsonObject jsonResponse = new JsonObject();
        jsonResponse.addProperty("status", "success");
        jsonResponse.addProperty("question", (String) questionMap.get("question"));

        // Create a JSON array to hold the answer options.
        JsonArray jsonAnswers = new JsonArray();
        for (String answer : (String[]) questionMap.get("answers")) {
            jsonAnswers.add(answer);
        }
        jsonResponse.add("answers", jsonAnswers);
        jsonResponse.addProperty("correctIndex", (int) questionMap.get("correctIndex"));

        // Convert the JSON object to a string and send it as the response.
        String responseData = new Gson().toJson(jsonResponse);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(responseData);

        // Record the time of the response and log the request, third-party API request, and response times.
        long responseTime = System.currentTimeMillis();
        String requestLog = String.format("[%d] %s %s %s - Requested: %s %s %s - Sent: %s",
                requestTime, phoneModel, request.getMethod(), request.getRequestURI(), category, difficulty, type, responseData);
        String thirdPartyApiLog = String.format("[%d] %s %s %s - Requested: %s %s %s - Response: %s",
                thirdPartyApiRequestTime, phoneModel, "GET", triviaModel.getApiUrl(category, difficulty, type), category, difficulty, type, response.getStatus());
        String responseLog = String.format("[%d] %s %s %s - Requested: %s %s %s - Response time: %dms",
                responseTime, phoneModel, request.getMethod(), request.getRequestURI(), category, difficulty, type, responseTime - requestTime);

        // Log the messages using the Java logging API.
        logger.log(Level.INFO, requestLog);
        logger.log(Level.INFO, thirdPartyApiLog);
        logger.log(Level.INFO, responseLog);

        // Insert the log data into the collection.
        Document logDocument = new Document("phoneModel", phoneModel)
                .append("category", category)
                .append("difficulty", difficulty)
                .append("type", type)
                .append("requestTime", requestTime)
                .append("thirdPartyApiRequestTime", thirdPartyApiRequestTime)
                .append("responseTime", responseTime);

        logCollection.insertOne(logDocument);


    }

    /**
     * Closes the connection to the MongoDB database when the servlet is destroyed.
     */
    @Override
    public void destroy() {
        super.destroy();

        // Close the connection to the MongoDB database when the servlet is destroyed.
        mongoClient.close();
    }
}