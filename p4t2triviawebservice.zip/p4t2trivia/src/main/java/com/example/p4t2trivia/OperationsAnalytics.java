/**
 * Name:Paridhi Kapur Andrew id:pkapur
 *
 * Author: Paridhi Kapur
 * Last Modified: April 8, 2023
 * This class provides functions to perform analytics on the logs collection
 * in a MongoDB database. It calculates the average response time, average request time,
 * and the number of requests made by the users.
 *
 *
 */
package com.example.p4t2trivia;

//import statements
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class OperationsAnalytics {

    // Connect to the MongoDB database and select the logs collection
    private static final MongoDatabase database = MongoClients.create("mongodb+srv://pkapur:distributed@cluster0.muxgpkw.mongodb.net/?retryWrites=true&w=majority")
            .getDatabase("logs");

    // Get the "trivia" collection from the "logs" database.
    private static final MongoCollection<Document> logCollection = database.getCollection("trivia");

    /**
     * Calculates the average response time of all requests made by the users.
     *
     * @return double Average response time in milliseconds.
     */
    public static double getAverageResponseTime() {
        long totalResponseTime = 0;
        int numRequests = 0;
        // Use try-with-resources statement to create a cursor for the "trivia" collection in MongoDB
        // Iterate through each document in the collection
        try (MongoCursor<Document> cursor = logCollection.find().iterator()) {
            while (cursor.hasNext()) {
                Document log = cursor.next();
                // If the document contains a "responseTime" field, add its value to the total response time
                // and increment the number of requests counter
                if (log.containsKey("responseTime")) {
                    totalResponseTime += log.getLong("responseTime");
                    numRequests++;
                }
            }
        }
        // Calculate and return the average response time if there were any responses, or 0 if there were none
        if (numRequests > 0) {
            return (double) totalResponseTime / numRequests;
        } else {
            return 0;
        }
    }

    /**
     * Calculates the average request time of all requests made by the users.
     *
     * @return double Average request time in milliseconds.
     */
    public static double getAverageRequestTime() {
        long totalRequestTime = 0;
        int numRequests = 0;
        // Use try-with-resources statement to create a cursor for the "trivia" collection in MongoDB
        // Iterate through each document in the collection
        try (MongoCursor<Document> cursor = logCollection.find().iterator()) {
            while (cursor.hasNext()) {
                Document log = cursor.next();
                // If the document contains a "requestTime" field, add its value to the total request time
                // and increment the number of requests counter
                if (log.containsKey("requestTime")) {
                   totalRequestTime += log.getLong("requestTime");
                    numRequests++;
                }
            }
        }
        // Calculate and return the average request time if there were any requests, or 0 if there were none

        if (numRequests > 0) {
            return (double) totalRequestTime / numRequests;
        } else {
            return 0;
        }
    }


    /**
     * Returns the number of requests made by the users.
     *
     * @return int Number of requests made by the users.
     */
    public static int getNumRequests() {
        return (int) logCollection.countDocuments();
    }

}
