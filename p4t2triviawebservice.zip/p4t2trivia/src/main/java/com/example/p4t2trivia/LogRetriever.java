/**
 * Name:Paridhi Kapur Andrew id:pkapur
 *
 * Author: Paridhi Kapur
 * Date: April 8, 2023
 * This program retrieves logs from a MongoDB database containing Trivia game logs.
 * It uses the MongoDB Java driver to connect to the database and retrieve all logs
 * from the "trivia" collection. It then iterates through each log document and creates
 * a LogEntry object for each valid log, containing the relevant fields. The LogEntry
 * objects are added to a List which is returned by the getAllLogs() method.

 */
package com.example.p4t2trivia;


//import statements
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;



public class LogRetriever {

    //initialize MongoDB database and collection objects
    private static final MongoDatabase database = MongoClients.create("mongodb+srv://pkapur:distributed@cluster0.muxgpkw.mongodb.net/?retryWrites=true&w=majority")
            .getDatabase("logs");
    private static final MongoCollection<Document> logCollection = database.getCollection("trivia");

    /**
     * Retrieves all logs from the "trivia" collection in the MongoDB database.
     *
     * @return A List of LogEntry objects representing the valid logs in the collection.
     */
    public static List<LogEntry> getAllLogs() {
        List<LogEntry> logs = new ArrayList<>();
        try (MongoCursor<Document> cursor = logCollection.find().iterator()) {
            while (cursor.hasNext()) {

                Document log = cursor.next();
                System.out.println(log);

                //check if log contains all required fields

                if (log.containsKey("phoneModel") && log.containsKey("category") && log.containsKey("difficulty") && log.containsKey("type") && log.containsKey("responseTime") && log.containsKey("requestTime")) {
                    // If the log contains all required fields, create a new LogEntry object using the data from the log.
                    LogEntry entry = new LogEntry(
                            log.getLong("requestTime").intValue(),
                            log.getString("phoneModel"),
                            log.getString("category"),
                            log.getString("difficulty"),
                            log.getString("type"),
                            log.getLong("responseTime").intValue()
                    );
                    // Add the new LogEntry object to the logs ArrayList.
                    logs.add(entry);
                }
            }
        }
        // Return the logs ArrayList.
        return logs;
    }
}