/**
 * Name:Paridhi Kapur Andrew id:pkapur
 *
 * Author: Paridhi Kapur
 * Date: April 8, 2023
 * This class represents a log entry for a trivia game request/response.
 * It includes fields for requestTime, phoneModel, category, difficulty,
 * type, and responseTime. It also includes getter methods for each field.
 *
 */
package com.example.p4t2trivia;


public class LogEntry {

    //define the parameters
    private final int requestTime;
    private final String phoneModel;
    private final String category;
    private final String difficulty;
    private final String type;
    private final int responseTime;

    /**
     * Constructs a LogEntry object with the given parameters.
     *
     * @param requestTime the time in milliseconds when the request was made
     * @param phoneModel the model of the phone used to make the request
     * @param category the category of the trivia question requested
     * @param difficulty the difficulty level of the trivia question requested
     * @param type the type of the trivia question requested (multiple choice, true/false, etc.)
     * @param responseTime the time in milliseconds it took to receive a response to the request
     */
    public LogEntry(int requestTime, String phoneModel, String category, String difficulty, String type, int responseTime) {
        this.requestTime = requestTime;
        this.phoneModel = phoneModel;
        this.category = category;
        this.difficulty = difficulty;
        this.type = type;
        this.responseTime = responseTime;
    }

    /**
     * Returns the time in milliseconds when the request was made.
     *
     * @return the request time
     */
    public int getrequestTime() {
        return requestTime;
    }

    /**
     * Returns the model of the phone used to make the request.
     *
     * @return the phone model
     */
    public String getPhoneModel() {
        return phoneModel;
    }

    /**
     * Returns the category of the trivia question requested.
     *
     * @return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * Returns the difficulty level of the trivia question requested.
     *
     * @return the difficulty level
     */
    public String getDifficulty() {
        return difficulty;
    }

    /**
     * Returns the type of the trivia question requested.
     *
     * @return the question type
     */
    public String getType() {
        return type;
    }

    /**
     * Returns the time in milliseconds it took to receive a response to the request.
     *
     * @return the response time
     */
    public int getResponseTime() {
        return responseTime;
    }
}